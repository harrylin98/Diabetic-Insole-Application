package com.example.myapplication;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.UUID;

public class AboutActivity extends AppCompatActivity  {

    TextView WHeel;
    TextView WFore;
    TextView WMid;
    TextView SHeel;
    TextView SFore;
    TextView SMid;
    TextView status;
    Button btn;
    String WH,WF,WM,SH,SF,SM;
    String BLE_status = "Bluetooth Status: Connected";
    static final UUID mUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    BluetoothAdapter btAdapter = BluetoothAdapter.getDefaultAdapter();
    BluetoothDevice hc05 = btAdapter.getRemoteDevice("98:D3:61:F9:86:9D");


    BluetoothSocket btSocket = null;
    int counter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        Intent intent = getIntent();
        int weight = Integer.parseInt(intent.getStringExtra("message_key"));

        WHeel = (TextView) findViewById(R.id.WHeel);
        WFore = (TextView) findViewById(R.id.WFore);
        WMid = (TextView) findViewById(R.id.WMid);
        SHeel = (TextView) findViewById(R.id.SHeel);
        SFore = (TextView) findViewById(R.id.SFore);
        SMid = (TextView) findViewById(R.id.SMid);

        WHeel.setText(String.format("%.2f", weight * 1.2 * 4.45 * 0.6/ 0.0009 /1000));
        WMid.setText(String.format("%.2f", weight * 1.2  * 4.45 * 0.1/ 0.0009 / 1000 ));
        WFore.setText(String.format("%.2f", weight * 0.8 * 0.14 * 4.45 / 0.0004 / 1000 ));

        WH = WHeel.getText().toString();
        WF = WFore.getText().toString();
        WM = WMid.getText().toString();

        SHeel.setText(String.format("%.2f", weight * 0.6 * 4.45 / 0.0018 / 1000));
        SFore.setText(String.format("%.2f", weight * 0.14 * 4.45 / 0.0008 / 1000));
        SMid.setText(String.format("%.2f", weight * 0.078 * 4.45 / 0.0018 / 1000));

        SH = SHeel.getText().toString();
        SF = SFore.getText().toString();
        SM = SMid.getText().toString();

        status = (TextView) findViewById(R.id.status);

        btn = (Button) findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {

                status.setText(BLE_status);

                do {
                    try {
                        btSocket = hc05.createRfcommSocketToServiceRecord(mUUID);

                        btSocket.connect();

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    counter++;
                } while (!btSocket.isConnected() && counter < 3);

                String IdealWalking = "IdealW " + WH + " " + WF + " " + WM + " ";
                String IdealStanding = "IdealS " + SH + " " + SF + " " + SM + " ";

                byte[] b = IdealWalking.getBytes();
                try {
                    OutputStream outputStream = btSocket.getOutputStream();
                    outputStream.write(b);
                } catch (IOException e) {
                    e.printStackTrace();
                }

                b = IdealStanding.getBytes();
                try {
                    OutputStream outputStream = btSocket.getOutputStream();
                    outputStream.write(b);
                } catch (IOException e) {
                    e.printStackTrace();
                }


                Intent intent = new Intent(AboutActivity.this, Mode.class);
                startActivity(intent);

                try {
                    btSocket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        });

    }

}

