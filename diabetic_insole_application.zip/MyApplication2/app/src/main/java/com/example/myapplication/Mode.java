package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.TextView;

import java.io.IOException;
import java.io.OutputStream;
import java.util.UUID;

public class Mode extends AppCompatActivity implements SensorEventListener {
    private static final String TAG = "Mode";
    private SensorManager sensorManager;
    Sensor accelerometer;
    TextView xValue, yValue, zValue, mode;
    String old_mode = "Standing";
    double old_magnitude = 0;

    static final UUID mUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    BluetoothAdapter btAdapter = BluetoothAdapter.getDefaultAdapter();
    BluetoothDevice hc05 = btAdapter.getRemoteDevice("98:D3:61:F9:86:9D");
    BluetoothSocket btSocket = null;
    int counter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mode);

        xValue = (TextView) findViewById(R.id.xValue);
        yValue = (TextView) findViewById(R.id.yValue);
        zValue = (TextView) findViewById(R.id.zValue);
        mode = (TextView) findViewById(R.id.Mode);

        mode.setText("Mode: Standing");
        Log.d(TAG, "Intializing Sensor Services");
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        sensorManager.registerListener(Mode.this,accelerometer,SensorManager.SENSOR_DELAY_NORMAL);

        Log.d(TAG,"Registerd accelerometer listerner");

        do {
            try {
                btSocket = hc05.createRfcommSocketToServiceRecord(mUUID);

                btSocket.connect();

            } catch (IOException e) {
                e.printStackTrace();
            }
            counter++;
        } while (!btSocket.isConnected() && counter < 3);


    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        Log.d(TAG,"onSensorChanged: X: " + event.values[0] + " Y: " + event.values[1] + " Z: " + event.values[2]);

        double x = event.values[0];
        double y =  event.values[1];
        double z =  event.values[2];
        double current_magnitude = Math.sqrt(x*x + y*y +z*z);


        xValue.setText("xValue: " + x);
        yValue.setText("yValue: " + y);
        zValue.setText("zValue: " + z);


        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {

                if (Math.abs(old_magnitude - current_magnitude) > 0.3)
                {
                    mode.setText("Mode: Walking");
                    old_mode = "Walking";
                    byte[] b = old_mode.getBytes();
                    try {
                        OutputStream outputStream = btSocket.getOutputStream();
                        outputStream.write(b);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                else
                {
                    mode.setText("Mode: Standing");
                    old_mode = "Standing";
                    byte[] b = old_mode.getBytes();
                    try {
                        OutputStream outputStream = btSocket.getOutputStream();
                        outputStream.write(b);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                old_magnitude = current_magnitude;

            }
        }, 3000);



    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}